# Compensation Workbook Skill

This repository contains a Codex skill for creating Chinese compensation calculation workbooks.

## Contents

- `compensation-workbook/SKILL.md`
- `compensation-workbook/agents/openai.yaml`
- `compensation-workbook/scripts/create_compensation_workbook.py`

## Usage

Copy the `compensation-workbook` folder into your Codex skills directory:

```powershell
Copy-Item -Recurse .\compensation-workbook "$env:USERPROFILE\.codex\skills\compensation-workbook"
```

Then ask Codex to use the `compensation-workbook` skill to create or update salary calculation workbooks.
