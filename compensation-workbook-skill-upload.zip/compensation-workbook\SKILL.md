---
name: compensation-workbook
description: Create or update Excel compensation workbooks for salary plans, base salary and performance-base adjusters, workload and performance scenarios, salary range assessments, promotion/demotion rules, leave handling, and special-case policy notes. Use when the user asks to build, revise, save, or reuse a薪酬测算表, salary calculator, compensation policy workbook, performance pay model, or promotion/demotion rules spreadsheet.
---

# Compensation Workbook

Use this skill to create or update a Chinese compensation workbook with linked salary calculations and policy pages.

## Default Workbook Shape

Create a workbook with these sheets in order:

1. `薪酬测算`: adjustable inputs and detailed scenario rows.
2. `薪酬方案`: policy explanation for salary standards, performance makeup, extra-fee rules, scenarios, and assumptions.
3. `测算评估`: low/mid/high performance salary range assessment by level.
4. `特殊情况说明`: long-term underperformance, demotion, penalties, leave, entry/exit, level adjustment, and promotion rules.

Use `scripts/create_compensation_workbook.py` when creating a fresh workbook or when the user wants the same structure rebuilt deterministically.

## Default Business Rules

- Levels:
  - 初级: base salary 4000, performance base 4000.
  - 中级: base salary 5000, performance base 5000.
  - 高级: base salary 6000, performance base 6000.
- Standards:
  - Standard course load: 24 lessons.
  - Standard training load: 8 sessions.
  - Training load means 真人培训 + 批课考核.
- Performance gradients: 50%, 70%, 90%, 100%.
- Default extra fees:
  - Extra course fee: 65 per lesson, adjustable.
  - Extra training fee: 90 per session, adjustable.
- Scenarios:
  - Low: 20 courses, 6 training sessions.
  - Standard: 24 courses, 8 training sessions.
  - Small extra: 28 courses, 10 training sessions.
  - Large extra: 36 courses, 16 training sessions.

## Core Formulas

- Performance salary = performance base * performance completion rate.
- Extra course fee = `MAX(actual courses - 24, 0) * course fee`.
- Extra training fee = `MAX(training total - 8, 0) * training fee`.
- Total salary = base salary + performance salary + extra course fee + extra training fee.

Keep base salary and performance base separate. The first sheet should include a visible salary adjuster where users can edit each level's base salary and performance base, and all linked formulas update.

## Policy Defaults

Use these policy statements unless the user provides different rules:

- Promotion review happens once every six months.
- Promotion eligibility requires comprehensive performance completion of 80% or above.
- Eligible employees may present and compete for the next higher role.
- Department负责人/部门负责人评估裁定 the promotion result.
- Demotion trigger:
  - Two consecutive months below 50% performance, or
  - Three consecutive months below 70% performance.
- Demotion should be reviewed and confirmed before execution, with the new level typically effective the following month.
- Penalties should not be silently mixed into the core salary formula. Add separate notes or columns if the user wants actual deduction calculations.
- Leave, entry/exit, and mid-month level changes require attendance or effective-date proration rules before being included in automated formulas.

## Updating Existing Workbooks

When editing an existing workbook:

- Preserve existing sheets and user-entered values where possible.
- Add or replace the relevant policy sheet only when requested.
- Keep formulas linked to the salary adjuster instead of hardcoding repeated base values.
- After editing, reopen the workbook with `openpyxl` and verify sheet order, key headers, and representative formulas.

## Script Usage

Run:

```bash
python scripts/create_compensation_workbook.py --output path/to/薪酬梯度测算表.xlsx
```

Optional arguments:

```bash
--course-rate 65
--training-rate 90
--course-standard 24
--training-standard 8
```

The script creates a complete four-sheet workbook with formulas, formatting, and default policy text.
