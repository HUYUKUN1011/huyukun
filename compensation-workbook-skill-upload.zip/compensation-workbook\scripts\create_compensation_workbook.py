import argparse
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


LEVELS = [("初级", 4000, 4000), ("中级", 5000, 5000), ("高级", 6000, 6000)]
SCENARIOS = [("低于标准", 20, 6), ("刚好达标", 24, 8), ("小幅超额", 28, 10), ("大幅超额", 36, 16)]
PERFORMANCE_RATES = [0.5, 0.7, 0.9, 1.0]


def styles():
    thin = Side(style="thin", color="999999")
    return {
        "yellow": PatternFill("solid", fgColor="FFF200"),
        "orange": PatternFill("solid", fgColor="F4B183"),
        "blue": PatternFill("solid", fgColor="D9EAF7"),
        "green": PatternFill("solid", fgColor="E2F0D9"),
        "red": PatternFill("solid", fgColor="FCE4D6"),
        "pale": PatternFill("solid", fgColor="FFF2CC"),
        "gray": PatternFill("solid", fgColor="F2F2F2"),
        "border": Border(left=thin, right=thin, top=thin, bottom=thin),
        "center": Alignment(horizontal="center", vertical="center", wrap_text=True),
        "left": Alignment(horizontal="left", vertical="center", wrap_text=True),
    }


def set_cell(cell, value, fill=None, bold=False, align=None, border=True):
    st = styles()
    cell.value = value
    if fill:
        cell.fill = st[fill]
    if bold:
        cell.font = Font(bold=True)
    cell.alignment = align or st["center"]
    if border:
        cell.border = st["border"]
    return cell


def add_section(ws, row, title, end_col):
    ws.cell(row, 1, title)
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=end_col)
    set_cell(ws.cell(row, 1), title, fill="orange", bold=True, align=styles()["left"])


def add_table(ws, start_row, rows, header_fill="yellow"):
    for r_idx, row in enumerate(rows, start=start_row):
        for c_idx, value in enumerate(row, start=1):
            set_cell(ws.cell(r_idx, c_idx), value, fill=header_fill if r_idx == start_row else None, bold=r_idx == start_row)


def build_measurement_sheet(wb, args):
    ws = wb.active
    ws.title = "薪酬测算"
    st = styles()

    ws["A1"] = "薪酬梯度测算表"
    ws.merge_cells("A1:J1")
    ws["A1"].font = Font(size=16, bold=True)
    ws["A1"].fill = st["yellow"]
    ws["A1"].alignment = st["center"]

    params = [
        ("参数", "数值", "说明"),
        ("正课标准", args.course_standard, "超过该节数后计算超额课时费"),
        ("培训标准", args.training_standard, "真人培训 + 批课考核合计超过该节数后计算超额培训费"),
        ("超额课时单价", args.course_rate, "默认65元/节，可改为50-80"),
        ("超额培训单价", args.training_rate, "默认90元/节，可改为80-100"),
    ]
    add_table(ws, 3, params)
    for row in range(4, 8):
        ws.cell(row, 2).fill = st["blue"]

    ws["A8"] = "薪资调整器"
    ws.merge_cells("A8:D8")
    set_cell(ws["A8"], "薪资调整器", fill="orange", bold=True)
    add_table(ws, 9, [("等级", "可调底薪", "可调绩效基数", "说明")])
    for r, (level, base, perf_base) in enumerate(LEVELS, start=10):
        values = [level, base, perf_base, "改这两列后，下方明细自动重算"]
        for c, value in enumerate(values, start=1):
            set_cell(ws.cell(r, c), value)
        ws.cell(r, 2).fill = st["pale"]
        ws.cell(r, 3).fill = st["pale"]

    headers = ["等级", "课量", "培训量合计", "绩效完成度", "底薪", "绩效基数", "绩效工资", "超额课时费", "超额培训费", "薪酬合计"]
    add_table(ws, 15, [headers])
    row = 16
    for level, _, _ in LEVELS:
        for _, courses, training in SCENARIOS:
            for perf in PERFORMANCE_RATES:
                values = [level, courses, training, perf]
                for c, value in enumerate(values, start=1):
                    set_cell(ws.cell(row, c), value)
                ws.cell(row, 5, f"=VLOOKUP(A{row},$A$10:$C$12,2,FALSE)")
                ws.cell(row, 6, f"=VLOOKUP(A{row},$A$10:$C$12,3,FALSE)")
                ws.cell(row, 7, f"=F{row}*D{row}")
                ws.cell(row, 8, f"=MAX(B{row}-$B$4,0)*$B$6")
                ws.cell(row, 9, f"=MAX(C{row}-$B$5,0)*$B$7")
                ws.cell(row, 10, f"=E{row}+G{row}+H{row}+I{row}")
                for c in range(1, 11):
                    set_cell(ws.cell(row, c), ws.cell(row, c).value)
                ws.cell(row, 4).number_format = "0%"
                for c in range(5, 11):
                    ws.cell(row, c).number_format = "#,##0"
                row += 1

    note_row = row + 1
    set_cell(ws.cell(note_row, 1), "说明", fill="green", bold=True)
    ws.cell(note_row, 2, "绩效完成度线性折算绩效工资；低于标准课量/培训量不倒扣；未计算个税、社保、请假扣款、奖金或补贴。")
    ws.merge_cells(start_row=note_row, start_column=2, end_row=note_row, end_column=10)
    for c in range(2, 11):
        ws.cell(note_row, c).border = st["border"]
        ws.cell(note_row, c).alignment = st["left"]

    for col, width in zip(range(1, 11), [12, 10, 16, 14, 12, 12, 12, 14, 14, 14]):
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.freeze_panes = "A16"
    ws.auto_filter.ref = f"A15:J{row - 1}"


def build_plan_sheet(wb):
    ws = wb.create_sheet("薪酬方案")
    ws["A1"] = "薪酬方案说明"
    ws.merge_cells("A1:F1")
    set_cell(ws["A1"], "薪酬方案说明", fill="yellow", bold=True)
    ws["A1"].font = Font(size=16, bold=True)
    add_section(ws, 3, "一、等级薪酬标准", 6)
    add_table(ws, 4, [
        ("等级", "底薪", "绩效基数", "正课标准", "培训标准", "说明"),
        ("初级", 4000, 4000, 24, 8, "可在测算页薪资调整器中修改"),
        ("中级", 5000, 5000, 24, 8, "可在测算页薪资调整器中修改"),
        ("高级", 6000, 6000, 24, 8, "可在测算页薪资调整器中修改"),
    ])
    add_section(ws, 9, "二、绩效考核构成", 6)
    add_table(ws, 10, [
        ("类型", "内容项", "指标核算", "占比", "测算梯度", "说明"),
        ("绩效考核指标", "新人培训下组率", "目标完成度", "15%", "50%/70%/90%/100%", "按梯度线性折算"),
        ("绩效考核指标", "备课合格率", "目标完成度", "15%", "50%/70%/90%/100%", "按梯度线性折算"),
        ("绩效考核指标", "监课合格率", "目标完成度", "25%", "50%/70%/90%/100%", "按梯度线性折算"),
        ("绩效考核指标", "服务合格率", "目标完成度", "25%", "50%/70%/90%/100%", "按梯度线性折算"),
        ("绩效考核指标", "投诉/退费", "目标完成度", "20%", "50%/70%/90%/100%", "按梯度线性折算"),
    ])
    add_section(ws, 17, "三、超额费用与计算规则", 6)
    add_table(ws, 18, [
        ("项目", "默认值", "范围", "计算规则", "测算页对应", "说明"),
        ("超额课时费", "65元/节", "50-80元/节", "MAX(实际课量-24,0)*课时单价", "B6", "只对超出24节部分计算"),
        ("超额培训费", "90元/节", "80-100元/节", "MAX(培训量合计-8,0)*培训单价", "B7", "培训量=真人培训+批课考核"),
        ("绩效工资", "按绩效基数", "调整器修改", "绩效基数*绩效完成度", "C10:C12", "和底薪分开调整"),
        ("薪酬合计", "自动计算", "/", "底薪+绩效工资+超额课时费+超额培训费", "明细表J列", "不含个税、社保、其他奖惩"),
    ])
    for col, width in zip(range(1, 7), [16, 18, 22, 28, 22, 34]):
        ws.column_dimensions[get_column_letter(col)].width = width


def build_assessment_sheet(wb):
    ws = wb.create_sheet("测算评估")
    ws["A1"] = "不同级别人员薪酬区间评估"
    ws.merge_cells("A1:H1")
    set_cell(ws["A1"], ws["A1"].value, fill="yellow", bold=True)
    ws["A1"].font = Font(size=16, bold=True)
    add_section(ws, 3, "一、表现档位定义", 8)
    add_table(ws, 4, [
        ("表现档位", "绩效区间", "课量区间", "培训区间", "管理解读", "下限场景", "上限场景", "说明"),
        ("低表现", "50%-70%", "20-24节", "6-8节", "未达标到刚达标", "20课/6培训/50%", "24课/8培训/70%", "不产生超额收入"),
        ("中表现", "70%-90%", "24-28节", "8-10节", "稳定达标到小幅超额", "24课/8培训/70%", "28课/10培训/90%", "含小幅超额激励"),
        ("高表现", "90%-100%", "28-36节", "10-16节", "小幅超额到高产出", "28课/10培训/90%", "36课/16培训/100%", "超额收入明显增加"),
    ])
    add_section(ws, 10, "二、薪酬区间评估", 8)
    headers = ("等级", "表现档位", "估算薪酬下限", "估算薪酬上限", "薪酬区间", "下限口径", "上限口径", "评估结论")
    add_table(ws, 11, [headers])
    performance = [
        ("低表现", 0.5, 20, 6, 0.7, 24, 8, "主要由底薪+部分绩效构成"),
        ("中表现", 0.7, 24, 8, 0.9, 28, 10, "进入稳定激励区间"),
        ("高表现", 0.9, 28, 10, 1.0, 36, 16, "超额收入拉开差距"),
    ]
    row = 12
    for level, adjust_row in [("初级", 10), ("中级", 11), ("高级", 12)]:
        for label, low_perf, low_course, low_training, high_perf, high_course, high_training, conclusion in performance:
            values = [level, label]
            for c, value in enumerate(values, start=1):
                set_cell(ws.cell(row, c), value)
            ws.cell(row, 3, f"='薪酬测算'!B{adjust_row}+'薪酬测算'!C{adjust_row}*{low_perf}+MAX({low_course}-'薪酬测算'!$B$4,0)*'薪酬测算'!$B$6+MAX({low_training}-'薪酬测算'!$B$5,0)*'薪酬测算'!$B$7")
            ws.cell(row, 4, f"='薪酬测算'!B{adjust_row}+'薪酬测算'!C{adjust_row}*{high_perf}+MAX({high_course}-'薪酬测算'!$B$4,0)*'薪酬测算'!$B$6+MAX({high_training}-'薪酬测算'!$B$5,0)*'薪酬测算'!$B$7")
            ws.cell(row, 5, f'=TEXT(C{row},"#,##0")&" - "&TEXT(D{row},"#,##0")')
            ws.cell(row, 6, f"{low_course}课/{low_training}培训/{int(low_perf * 100)}%")
            ws.cell(row, 7, f"{high_course}课/{high_training}培训/{int(high_perf * 100)}%")
            ws.cell(row, 8, conclusion)
            for c in range(1, 9):
                set_cell(ws.cell(row, c), ws.cell(row, c).value)
            row += 1
    for col, width in zip(range(1, 9), [12, 12, 16, 16, 18, 18, 18, 34]):
        ws.column_dimensions[get_column_letter(col)].width = width


def build_special_cases_sheet(wb):
    ws = wb.create_sheet("特殊情况说明")
    ws["A1"] = "特殊情况、长期不达标与等级调整说明"
    ws.merge_cells("A1:G1")
    set_cell(ws["A1"], ws["A1"].value, fill="yellow", bold=True)
    ws["A1"].font = Font(size=16, bold=True)
    add_section(ws, 3, "一、特殊情况处理口径", 7)
    add_table(ws, 4, [("类别", "特殊情况", "触发条件/判断口径", "处理建议", "薪酬影响", "需要记录/审批", "备注")])
    rows = [
        ("长期不达标", "连续低绩效", "连续2个月绩效完成度低于50%，或连续3个月绩效完成度低于70%", "触发降级评估或强制改善期", "当月按实际绩效梯度发放；降级通过后次月按新等级执行", "绩效数据+改善记录", "作为降级触发线，不代表自动扣罚"),
        ("降级机制", "改善期后仍不达标", "符合降级触发线：连续2个月低于50%，或连续3个月低于70%；经评估确认后执行", "次月起降一级执行；初级可转入待改善/待观察状态", "按新级别底薪和绩效基数计算", "主管复核+HR审批", "需结合业务原因和数据异常复核"),
        ("扣罚机制", "服务事故/重大投诉", "有效投诉、重大退费、严重违反服务流程且完成定责", "先通过绩效项扣减；额外扣罚必须单独审批并明确上限", "降低绩效工资；额外扣罚不自动计算", "定责记录+扣罚审批", "避免同一事项重复扣罚"),
        ("请假", "请假导致工作量不完整", "按公司考勤规则确认有薪/无薪假和折算天数", "底薪和绩效基数可按出勤比例折算；超额项按实际数据计", "影响底薪、绩效基数和当月课量/培训量", "请假审批+考勤记录", "需要出勤比例规则后再纳入自动计算"),
        ("等级调整", "半年度晋级判定或降级调整", "每半年统一判定一次；申请晋级需综合绩效完成度达到80%及以上", "符合门槛者可述职竞聘高一级岗位；由部门负责人评估裁定", "晋级通过后按新等级底薪和绩效基数执行", "半年度绩效数据+述职材料+评估结果", "建议裁定后次月生效"),
    ]
    for r, row in enumerate(rows, start=5):
        for c, value in enumerate(row, start=1):
            set_cell(ws.cell(r, c), value, align=styles()["left"] if c > 1 else styles()["center"])
    add_section(ws, 12, "二、晋级判定流程", 7)
    add_table(ws, 13, [
        ("步骤", "环节", "判断/执行口径", "输出结果", "负责人/参与方", "记录材料", "备注"),
        ("1", "半年度判定", "每半年统一进行一次等级判定", "确认可申请晋级人员池", "部门负责人/HR", "半年度名单与等级记录", "不建议随时晋级"),
        ("2", "绩效门槛", "综合绩效完成度达到80%及以上", "达到晋级述职基础门槛", "直属主管/HR", "半年度绩效汇总", "达到80%只代表可申请，不等于自动晋级"),
        ("3", "述职竞聘", "候选人围绕业绩、能力、岗位匹配度进行述职", "形成述职评估意见", "候选人/评估人", "述职材料+评分表", "可竞聘高一级岗位"),
        ("4", "评估裁定", "由部门负责人结合述职和业务需求评估裁定", "通过/暂不通过/延期观察", "部门负责人", "评估结果和审批记录", "以评估裁定为最终依据"),
    ])
    for col, width in zip(range(1, 8), [14, 24, 34, 34, 30, 24, 34]):
        ws.column_dimensions[get_column_letter(col)].width = width


def build_workbook(args):
    wb = Workbook()
    build_measurement_sheet(wb, args)
    build_plan_sheet(wb)
    build_assessment_sheet(wb)
    build_special_cases_sheet(wb)
    return wb


def main():
    parser = argparse.ArgumentParser(description="Create a Chinese compensation calculation workbook.")
    parser.add_argument("--output", required=True, help="Output .xlsx path")
    parser.add_argument("--course-rate", type=float, default=65)
    parser.add_argument("--training-rate", type=float, default=90)
    parser.add_argument("--course-standard", type=float, default=24)
    parser.add_argument("--training-standard", type=float, default=8)
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    wb = build_workbook(args)
    wb.save(output)
    print(output)


if __name__ == "__main__":
    main()
